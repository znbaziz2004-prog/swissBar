<section class="kk-how-it-works">

    <div class="kk-how-bg-shape kk-how-bg-shape-1"></div>
    <div class="kk-how-bg-shape kk-how-bg-shape-2"></div>
    <div class="kk-how-bg-shape kk-how-bg-shape-3"></div>

    <div class="kk-how-inner">

        <div class="kk-how-heading">

            <span class="kk-how-kicker">
                <?php echo e(__('messages.simple_steps')); ?>

            </span>

            <h2>
                <?php echo e(__('messages.how_it_works')); ?>

            </h2>

            <p>
                <?php echo e(__('messages.how_it_works_description')); ?><br>
                <?php echo e(__('messages.how_it_works_subtitle')); ?>

            </p>

        </div>

        <div class="kk-how-grid">

            <article class="kk-how-card">

                <div class="kk-how-number">01</div>

                <div class="kk-how-image">
                    <img
                        src="<?php echo e(asset('images/step-01.png')); ?>"
                        alt="<?php echo e(__('messages.find_your_barber')); ?>"
                    >
                </div>

                <div class="kk-how-content">
                    <h3><?php echo e(__('messages.find_your_barber')); ?></h3>
                    <p><?php echo e(__('messages.find_your_barber_description')); ?></p>
                </div>

            </article>

            <article class="kk-how-card">

                <div class="kk-how-number">02</div>

                <div class="kk-how-image">
                    <img
                        src="<?php echo e(asset('images/step-02.png')); ?>"
                        alt="<?php echo e(__('messages.make_appointment')); ?>"
                    >
                </div>

                <div class="kk-how-content">
                    <h3><?php echo e(__('messages.make_appointment')); ?></h3>
                    <p><?php echo e(__('messages.make_appointment_description')); ?></p>
                </div>

            </article>

            <article class="kk-how-card">

                <div class="kk-how-number">03</div>

                <div class="kk-how-image">
                    <img
                        src="<?php echo e(asset('images/step-03.png')); ?>"
                        alt="<?php echo e(__('messages.take_advantage')); ?>"
                    >
                </div>

                <div class="kk-how-content">
                    <h3><?php echo e(__('messages.take_advantage')); ?></h3>
                    <p><?php echo e(__('messages.take_advantage_description')); ?></p>
                </div>

            </article>

        </div>

    </div>

</section><?php /**PATH E:\Zainab's folder\swiss\swiss\website\resources\views/components/how-it-works.blade.php ENDPATH**/ ?>