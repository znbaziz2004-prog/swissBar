<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(__('messages.payment_page_title')); ?></title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f5f6f8;
            color: #222;
        }

        .header {
            background: #17251f;
            color: white;
            padding: 22px 7%;
        }

        .header h1 {
            margin: 0;
            font-size: 25px;
        }

        .container {
            max-width: 1100px;
            margin: 45px auto;
            padding: 0 20px;
        }

        .intro {
            text-align: center;
            margin-bottom: 35px;
        }

        .intro h2 {
            font-size: 32px;
            margin-bottom: 10px;
        }

        .intro p {
            color: #666;
        }

        .plans {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 22px;
        }

        .plan {
            background: white;
            padding: 28px;
            border-radius: 12px;
            border: 1px solid #e4e7e5;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.04);
        }

        .plan h3 {
            font-size: 23px;
            margin-top: 0;
        }

        .price {
            font-size: 32px;
            font-weight: bold;
            margin: 20px 0 8px;
        }

        .period {
            color: #777;
            font-size: 14px;
        }

        .description {
            color: #666;
            line-height: 1.6;
            min-height: 45px;
        }

        .select-button {
            display: block;
            width: 100%;
            margin-top: 25px;
            padding: 13px;
            background: #1d382b;
            color: white;
            border: none;
            border-radius: 7px;
            font-size: 15px;
            text-align: center;
            cursor: pointer;
            opacity: 1;
        }

        .select-button:disabled {
            cursor: not-allowed;
            opacity: 0.7;
        }

        .message {
            background: #fff;
            padding: 18px;
            border-radius: 8px;
            text-align: center;
            margin-bottom: 20px;
        }

        .error {
            color: #b42318;
        }

        @media (max-width: 600px) {
            .intro h2 {
                font-size: 26px;
            }

            .container {
                margin-top: 30px;
            }
        }
    </style>
</head>

<body>
    <header class="header">
        <h1>Swiss Barber</h1>
    </header>

    <main class="container">
        <section class="intro">

            <?php if(session('error')): ?>
                <div class="message error">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>

            <?php if(request()->query('cancelled') === 'true'): ?>
                <div class="message error">
                    <?php echo e(__('messages.payment_cancelled')); ?>

                </div>
            <?php endif; ?>

            <?php if(!empty($paymentMessage)): ?>
                <div class="message">
                    <?php echo e($paymentMessage); ?>

                </div>
            <?php endif; ?>

            <?php if(!empty($paymentError)): ?>
                <div class="message error">
                    <?php echo e($paymentError); ?>

                </div>
            <?php endif; ?>

            <h2><?php echo e(__('messages.payment_choose_subscription')); ?></h2>

            <p><?php echo e(__('messages.payment_choose_description')); ?></p>
        </section>

        <?php if(!empty($subscription)): ?>
            <div class="message">
                <h3><?php echo e(__('messages.payment_current_subscription')); ?></h3>

                <p>
                    <strong><?php echo e(__('messages.payment_shop')); ?>:</strong>
                    <?php echo e($subscription['shop_name'] ?? __('messages.payment_your_barbershop')); ?>

                </p>

                <p>
                    <strong><?php echo e(__('messages.payment_plan')); ?>:</strong>
                    <?php echo e($subscription['plan_name'] ?? __('messages.payment_not_available')); ?>

                </p>

                <p>
                    <strong><?php echo e(__('messages.payment_status')); ?>:</strong>
                    <?php echo e(__('messages.payment_status_' . strtolower($subscription['status'] ?? 'unknown'))); ?>

                </p>

                <?php if(($subscription['status'] ?? '') === 'active'): ?>
                    <p><?php echo e(__('messages.payment_subscription_active_message')); ?></p>
                <?php elseif(($subscription['status'] ?? '') === 'pending'): ?>
                    <p><?php echo e(__('messages.payment_subscription_pending_message')); ?></p>
                <?php endif; ?>
            </div>
        <?php elseif(!empty($subscriptionError)): ?>
            <div class="message error">
                <?php echo e($subscriptionError); ?>

            </div>
        <?php endif; ?>

        <?php if(!empty($error)): ?>
            <div class="message error">
                <?php echo e($error); ?>

            </div>
        <?php elseif(empty($plans)): ?>
            <div class="message">
                <?php echo e(__('messages.payment_no_plans')); ?>

            </div>
        <?php else: ?>
            <div class="plans">
                <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="plan">
                        <h3>
                            <?php echo e($plan['name'] ?? $plan['plan_name'] ?? __('messages.payment_subscription_plan')); ?>

                        </h3>

                        <div class="price">
                            CHF <?php echo e(number_format((float) ($plan['price'] ?? 0), 2)); ?>

                        </div>

                        <div class="period">
                            <?php
                                $billingInterval = strtolower($plan['billing_interval'] ?? 'monthly');
                            ?>

                            <?php if(in_array($billingInterval, ['monthly', 'month'])): ?>
                                <?php echo e(__('messages.payment_monthly')); ?>

                            <?php elseif(in_array($billingInterval, ['yearly', 'annually', 'year'])): ?>
                                <?php echo e(__('messages.payment_yearly')); ?>

                            <?php else: ?>
                                <?php echo e($plan['billing_interval'] ?? __('messages.payment_monthly')); ?>

                            <?php endif; ?>
                        </div>

                        
<?php
    $planName = strtolower(trim(
        $plan['name'] ?? $plan['plan_name'] ?? ''
    ));

    if ($planName === 'starter') {
        $planDescription = __('messages.plan_starter_description');
    } elseif ($planName === 'professional') {
        $planDescription = __('messages.plan_professional_description');
    } elseif ($planName === 'business') {
        $planDescription = __('messages.plan_business_description');
    } else {
        $planDescription = $plan['description']
            ?? __('messages.payment_plan_description');
    }
?>

<p class="description">
    <?php echo e($planDescription); ?>

</p>


                        <?php if(
                            !empty($subscription) &&
                            ($subscription['status'] ?? '') === 'pending'
                        ): ?>
                            <form
                                method="POST"
                                action="<?php echo e(route('subscription.checkout')); ?>"
                            >
                                <?php echo csrf_field(); ?>

                                <button class="select-button" type="submit">
                                    <?php echo e(__('messages.payment_pay')); ?>

                                    CHF <?php echo e(number_format((float) ($subscription['price'] ?? 0), 2)); ?>

                                </button>
                            </form>

                        <?php elseif(!empty($subscription) && ($subscription['status'] ?? '') === 'active'): ?>
                            <button class="select-button" type="button" disabled>
                                <?php echo e(__('messages.payment_subscription_active_button')); ?>

                            </button>

                        <?php else: ?>
                            <button class="select-button" type="button" disabled>
                                <?php echo e(__('messages.payment_complete_registration')); ?>

                            </button>
                        <?php endif; ?>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </main>
</body>
</html><?php /**PATH E:\Zainab's folder\swiss\swiss\website\resources\views/pages/subscription-payment.blade.php ENDPATH**/ ?>