<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <title><?php echo $__env->yieldContent('title', 'Swiss Barber'); ?></title>

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <meta
        name="description"
        content="Maak online een afspraak bij je kapper met Swiss Barber. Vind een lokale kapper, kies een tijd en voorkom wachten."
    >

    <meta
        name="theme-color"
        content="#000000"
    >

    <title>
        <?php echo $__env->yieldContent('title', 'Swiss Barber'); ?>
    </title>

    <?php echo app('Illuminate\Foundation\Vite')([
        'resources/css/app.css',
        'resources/js/app.js'
    ]); ?>

    <?php echo $__env->yieldPushContent('head'); ?>

</head>


<body>

    <div class="kk-page<?php echo e(request()->routeIs('home') ? ' kk-home-page' : ''); ?>">

        <?php echo $__env->make('components.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>

        <?php echo $__env->make('components.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    </div>


    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>

</html>
<?php /**PATH E:\Zainab's folder\swiss\swiss\website\resources\views/layouts/app.blade.php ENDPATH**/ ?>