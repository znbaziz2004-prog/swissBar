<header class="kk-header">
    <div class="kk-header-inner">

        <a href="<?php echo e(route('home')); ?>" class="kk-brand">
            <span class="kk-brand-script">Swiss Barber</span>
        </a>

       <nav class="kk-main-nav">
    <a href="<?php echo e(route('search')); ?>"><?php echo e(__('messages.search')); ?></a>
    <a href="<?php echo e(route('info')); ?>"><?php echo e(__('messages.info')); ?></a>
    <a href="<?php echo e(route('contact')); ?>"><?php echo e(__('messages.contact')); ?></a>
   <a href="/customer/login">
    <?php echo e(__('messages.customer_portal')); ?>

</a>
</nav>

        <div class="kk-header-actions" style="display: flex; align-items: center; gap: 12px;">
            <a href="<?php echo e(route('register')); ?>" class="kk-register">
    <?php echo e(__('messages.register_barbershop')); ?>

</a>

<a href="<?php echo e(route('login')); ?>" class="kk-login">
    <?php echo e(__('messages.login')); ?>

    <span>→</span>
</a>

           
<div class="kk-language-wrapper">
    <button class="kk-language" type="button" id="kkLanguageButton">
        <span class="kk-flag" id="kkCurrentFlag">
            <?php echo e(['en' => '🇬🇧', 'de' => '🇩🇪', 'fr' => '🇫🇷', 'it' => '🇮🇹', 'rm' => '🇨🇭'][session('locale', 'en')] ?? '🇬🇧'); ?>

        </span>

        <span id="kkCurrentLanguage">
            <?php echo e(strtoupper(session('locale', 'en'))); ?>

        </span>

        <span class="kk-chevron">⌄</span>
    </button>

    <div class="kk-language-dropdown" id="kkLanguageDropdown">
        <form method="POST" action="<?php echo e(route('language.switch', 'en')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit">🇬🇧 English</button>
        </form>

        <form method="POST" action="<?php echo e(route('language.switch', 'de')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit">🇩🇪 Deutsch</button>
        </form>

        <form method="POST" action="<?php echo e(route('language.switch', 'fr')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit">🇫🇷 Français</button>
        </form>

        <form method="POST" action="<?php echo e(route('language.switch', 'it')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit">🇮🇹 Italiano</button>
        </form>

        <form method="POST" action="<?php echo e(route('language.switch', 'rm')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit">🇨🇭 Rumantsch</button>
        </form>
    </div>
</div>
        </div>

        <button class="kk-menu-button" id="kkMenuButton" type="button">
            <span></span>
            <span></span>
            <span></span>
        </button>

    </div>

    <div class="kk-mobile-nav" id="kkMobileNav">
    <a href="<?php echo e(route('search')); ?>"><?php echo e(__('messages.search')); ?></a>
    <a href="<?php echo e(route('info')); ?>"><?php echo e(__('messages.info')); ?></a>
    <a href="<?php echo e(route('contact')); ?>"><?php echo e(__('messages.contact')); ?></a>
    <a href="/customer/login">
    <?php echo e(__('messages.customer_portal')); ?>

</a>

    <a href="<?php echo e(route('register')); ?>" class="kk-register">
        <?php echo e(__('messages.register_barbershop')); ?>

    </a>

    <a href="<?php echo e(route('login')); ?>">
        <?php echo e(__('messages.login')); ?> →
    </a>
</div>
</header><?php /**PATH E:\Zainab's folder\swiss\swiss\website\resources\views/components/navbar.blade.php ENDPATH**/ ?>