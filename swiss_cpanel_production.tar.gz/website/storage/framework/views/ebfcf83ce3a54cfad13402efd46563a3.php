<footer class="swiss-footer">
    <div class="swiss-footer-inner">

        
        <div class="swiss-footer-brand">
            <a href="<?php echo e(route('home')); ?>" class="swiss-footer-logo">
                Swiss Barber
            </a>

            <p><?php echo e(__('messages.footer_tagline')); ?></p>

            <a href="<?php echo e(route('contact')); ?>" class="swiss-footer-contact-link">
                <?php echo e(__('messages.get_in_touch')); ?> →
            </a>
        </div>

        
        <div class="swiss-footer-column">
            <h3><?php echo e(__('messages.explore')); ?></h3>

            <a href="<?php echo e(route('home')); ?>"><?php echo e(__('messages.home')); ?></a>
            <a href="<?php echo e(route('search')); ?>"><?php echo e(__('messages.search')); ?></a>
            <a href="<?php echo e(route('info')); ?>"><?php echo e(__('messages.info')); ?></a>
            <a href="<?php echo e(route('contact')); ?>"><?php echo e(__('messages.contact')); ?></a>
        </div>

        
        <div class="swiss-footer-column">
            <h3><?php echo e(__('messages.portals')); ?></h3>

            <a href="<?php echo e(route('register-info')); ?>">
                <?php echo e(__('messages.register_barbershop')); ?>

            </a>

            <a href="<?php echo e(route('login')); ?>">
                <?php echo e(__('messages.login')); ?>

            </a>

            <a href="/customer/login">
                <?php echo e(__('messages.customer_portal')); ?>

            </a>

            <a href="/admin/login">
                <?php echo e(__('messages.admin_panel')); ?>

            </a>
        </div>

        
        <div class="swiss-footer-column">
            <h3><?php echo e(__('messages.legal')); ?></h3>

            <a href="<?php echo e(route('terms-of-use')); ?>">
                <?php echo e(__('messages.terms_of_use')); ?>

            </a>

            <a href="<?php echo e(route('privacy-policy')); ?>">
                <?php echo e(__('messages.privacy_policy')); ?>

            </a>
        </div>
    </div>

    
    <div class="swiss-footer-bottom">
        <p>
            © <?php echo e(date('Y')); ?> Swiss Barber.
            <?php echo e(__('messages.footer_rights')); ?>

        </p>

        <div class="swiss-footer-bottom-links">
            <a href="<?php echo e(route('terms-of-use')); ?>">
                <?php echo e(__('messages.terms_of_use')); ?>

            </a>

            <span></span>

            <a href="<?php echo e(route('privacy-policy')); ?>">
                <?php echo e(__('messages.privacy_policy')); ?>

            </a>
        </div>
    </div>
</footer><?php /**PATH E:\Zainab's folder\swiss\swiss\website\resources\views/components/footer.blade.php ENDPATH**/ ?>