<?php $__env->startSection('title', __('messages.login_title')); ?>

<?php $__env->startSection('top_action'); ?>
    <?php echo e(__('messages.login_new_here')); ?>

    <a href="<?php echo e(route('register')); ?>">
        <?php echo e(__('messages.login_create_account')); ?> →
    </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('story'); ?>
    <p class="swiss-auth-eyebrow"><?php echo e(__('messages.login_eyebrow')); ?></p>

    <h1><?php echo e(__('messages.login_story_heading')); ?></h1>

    <p class="swiss-auth-story-copy">
        <?php echo e(__('messages.login_story_copy')); ?>

    </p>

    <ul class="swiss-auth-benefits">
        <li><span class="swiss-auth-benefit-mark">✓</span><?php echo e(__('messages.login_benefit_1')); ?></li>
        <li><span class="swiss-auth-benefit-mark">✓</span><?php echo e(__('messages.login_benefit_2')); ?></li>
        <li><span class="swiss-auth-benefit-mark">✓</span><?php echo e(__('messages.login_benefit_3')); ?></li>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('form_content'); ?>
    <div class="swiss-auth-card-heading">
        <h2><?php echo e(__('messages.login_welcome')); ?></h2>
        <p><?php echo e(__('messages.login_subtitle')); ?></p>
    </div>

    <?php if(session('status')): ?>
        <div class="swiss-auth-alert swiss-auth-alert--success" role="status">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->has('login')): ?>
        <div class="swiss-auth-alert" role="alert">
            <?php echo e($errors->first('login')); ?>

        </div>
    <?php endif; ?>

    <form class="swiss-auth-form" action="<?php echo e(route('login.submit')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="swiss-auth-field">
            <label for="email">
                <?php echo e(__('messages.login_email')); ?>

                <span class="swiss-auth-required">*</span>
            </label>

            <input
                id="email"
                name="email"
                type="email"
                value="<?php echo e(old('email')); ?>"
                required
                autocomplete="username"
                autofocus
                placeholder="<?php echo e(__('messages.login_email_placeholder')); ?>"
            >

            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="swiss-auth-error"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="swiss-auth-field">
            <label for="password">
                <?php echo e(__('messages.login_password')); ?>

                <span class="swiss-auth-required">*</span>
            </label>

            <input
                id="password"
                name="password"
                type="password"
                required
                autocomplete="current-password"
                placeholder="<?php echo e(__('messages.login_password_placeholder')); ?>"
            >

            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="swiss-auth-error"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <?php if($errors->has('email') || $errors->has('password')): ?>
            <div class="swiss-auth-alert" role="alert">
                <?php echo e($errors->first('email') ?: $errors->first('password')); ?>

            </div>
        <?php endif; ?>

        <button class="swiss-auth-button" type="submit">
            <?php echo e(__('messages.login_button')); ?>

            <span aria-hidden="true">→</span>
        </button>
    </form>

    <p class="swiss-auth-card-footer">
        <?php echo e(__('messages.login_need_account')); ?>

        <a class="swiss-auth-inline-link" href="<?php echo e(route('register')); ?>">
            <?php echo e(__('messages.login_register_shop')); ?>

        </a>
    </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Zainab's folder\swiss\swiss\website\resources\views/auth/login.blade.php ENDPATH**/ ?>