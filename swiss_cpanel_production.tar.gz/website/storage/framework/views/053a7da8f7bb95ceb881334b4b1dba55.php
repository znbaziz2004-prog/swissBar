<section class="kk-reviews" id="reviews">
    <div class="kk-reviews-inner">

        <div class="kk-reviews-heading">
            <p><?php echo e(__('messages.reviews_heading')); ?></p>
        </div>

        <div class="kk-reviews-slider">

            <button
                type="button"
                class="kk-reviews-arrow kk-reviews-prev"
                aria-label="<?php echo e(__('messages.previous_testimonials')); ?>"
            >
                ‹
            </button>

            <div class="kk-reviews-viewport">
                <div class="kk-reviews-track">

                    <?php $__empty_1 = true; $__currentLoopData = $testimonials ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <article class="kk-review-card">
                            <div class="kk-review-quote">“</div>

                            <?php
    $currentLocale = app()->getLocale();

    $reviewTranslations = $testimonial['translations'] ?? [];

    if (is_string($reviewTranslations)) {
        $reviewTranslations = json_decode($reviewTranslations, true) ?? [];
    }

    $displayTestimonial = $reviewTranslations[$currentLocale]
        ?? $testimonial['testimonial']
        ?? '';
?>

<p class="kk-review-text">
    <?php echo e($displayTestimonial); ?>

</p>

                            <div class="kk-review-author">
                                <div class="kk-review-avatar kk-review-initial">
                                    <?php echo e(strtoupper(substr($testimonial['shop_name'] ?? 'B', 0, 1))); ?>

                                </div>

                                <div>
                                    <strong>
                                        <?php echo e($testimonial['shop_name'] ?? 'Barbershop'); ?>

                                    </strong>
                                    <span><?php echo e(__('messages.swiss_barber_partner')); ?></span>
                                </div>
                            </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <article class="kk-review-card">
                            <div class="kk-review-quote">“</div>

                            <p class="kk-review-text">
    <?php echo e(__("messages.reviews_empty_message")); ?>

</p>

                            <div class="kk-review-author">
                                <div class="kk-review-avatar kk-review-initial">
                                    S
                                </div>

                                <div>
                                    <strong><?php echo e(__('messages.swiss_barber')); ?></strong>
<span><?php echo e(__('messages.our_barbers')); ?></span>
                                </div>
                            </div>
                        </article>
                    <?php endif; ?>

                </div>
            </div>

            <button
                type="button"
                class="kk-reviews-arrow kk-reviews-next"
                aria-label="<?php echo e(__('messages.next_testimonials')); ?>"
            >
                ›
            </button>

        </div>
    </div>
</section>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const track = document.querySelector('.kk-reviews-track');

    if (!track) return;

    const originalCards = Array.from(
        track.querySelectorAll('.kk-review-card')
    );

    // Duplicate cards only when there is more than one.
    if (originalCards.length > 1) {
        originalCards.forEach(function (card) {
            const clone = card.cloneNode(true);
            clone.setAttribute('aria-hidden', 'true');
            track.appendChild(clone);
        });
    }
});
</script>
<?php $__env->stopPush(); ?><?php /**PATH E:\Zainab's folder\swiss\swiss\website\resources\views/components/reviews.blade.php ENDPATH**/ ?>